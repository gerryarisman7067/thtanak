# SIKAR-FORWARD CHAINING
Sistem Pakar Diagnosa Tanaman Sayur berbasis web dengan Forward Chaining

Aplikasi ini di buat menggunakan PHP, MySQL dan Bootstrap 4, aplikasi ini bertujuan untuk
mendeteksi diagnosa penyakit pada tanaman sayur sehingga dapat cara terbaik untuk penaggulangannya seperti,
penyebab, solusi, dan cara mengobati juga teknik pengobatannya, aplikasi ini free bisa anda kembangkan dan bisa anda modifikasi
untuk aplikasi lainnya silahkan cek www.hakkoblogs.com
