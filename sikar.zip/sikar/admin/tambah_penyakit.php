<?php
include('templates/header.php');
?>
<div class="container-fluid">
    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">TAMBAH PENYAKIT</h6>
        </div>
        <div class="col-md-6">
            <div class="card-body">

                <form action="" method="POST">
                    <div class="form-group">
                        <label for="kode">KODE PENYAKIT</label>
                        <input type="text" class="form-control" name="kode" id="kode" required placeholder="Contoh P01">
                    </div>
                    <div class="form-group">
                        <label for="nama">NAMA PENYAKIT</label>
                        <input type="text" class="form-control" name="nama" id="nama" required>
                    </div>
                    <div class="form-group">
                        <label for="penyebab">PENYEBAB</label>
                        <input type="text" class="form-control" name="penyebab" id="penyebab" required>
                    </div>
                    <input type="submit" class="btn btn-primary" name="submit" value="Tambah">

                    <?php
                    include('../conn.php');
                    if (isset($_POST['submit'])) {
                        $kode          = ($_POST['kode']);
                        $nama          = ($_POST['nama']);
                        $penyebab      = ($_POST['penyebab']);

                        $query = mysqli_query($koneksi, "INSERT INTO penyakit (kode, nama_penyakit, penyebab) VALUES ('$kode','$nama','$penyebab')");

                        if ($query) {
                            echo '<script language="javascript">';
                            echo 'alert("Data Berhasil disimpan")';
                            echo '</script>';
                        }
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
include('templates/footer.php');
?>