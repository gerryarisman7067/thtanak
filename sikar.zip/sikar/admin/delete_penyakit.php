<?php
//including the database connection file
include('../conn.php');

//deleting the row from table
$result = mysqli_query($koneksi, "DELETE FROM penyakit WHERE kode = '" . $_GET['id'] . "'");

//redirecting to the display page (index.php in our case)
header("Location:penyakit.php");
