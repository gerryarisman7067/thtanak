<?php
//including the database connection file
include('../conn.php');

//deleting the row from table
$result = mysqli_query($koneksi, "DELETE FROM gejala WHERE kd_gejala = '" . $_GET['id'] . "'");

//redirecting to the display page (index.php in our case)
header("Location:gejala.php");
