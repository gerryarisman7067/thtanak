<?php
include('templates/header.php');
?>
<div class="container-fluid">
    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">EDIT GEJALA</h6>
        </div>
        <div class="col-md-6">
            <div class="card-body">
                <?php
                include('../conn.php');
                $id  = $_GET['id'];
                $sql  = mysqli_query($koneksi, "SELECT * FROM gejala WHERE kd_gejala='$id'");
                $data = mysqli_fetch_assoc($sql);
                ?>
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="kode">KODE GEJALA</label>
                        <input type="text" class="form-control" name="kode" id="kode" value="<?= $data['kd_gejala']; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama">NAMA GEJALA</label>
                        <input type="text" class="form-control" name="nama" id="nama" value="<?= $data['gejala']; ?>" required>
                    </div>
                    <input type="submit" class="btn btn-primary" name="submit" value="SIMPAN">
                    <?php
                    include('../conn.php');
                    if (isset($_POST['submit'])) {
                        $id = $_GET['id'];
                        $kode         = $_POST['kode'];
                        $nama         = $_POST['nama'];

                        // perintah query untuk mengubah data pada tabel is_siswa
                        $query = mysqli_query($koneksi, "UPDATE gejala SET gejala = '$nama' WHERE kd_gejala = '$id'");

                        if ($query) {
                            echo '<script language="javascript">';
                            echo 'alert("Data Berhasil disimpan")';
                            echo '</script>';
                            echo '<script> location.replace("gejala.php"); </script>';
                        }
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include('templates/footer.php');
?>