<?php
include('templates/header.php');
?>
<div class="container-fluid">
    <a href="tambah_gejala.php" class="btn btn-primary">Tambah</a>
    <!-- DataTales Example -->
    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DAFTAR GEJALA PENYAKIT THT</h6>
        </div>
        <div class="card-body">
            <?php
            //including the database connection file
            include('../conn.php');

            //fetching data in descending order (lastest entry first)
            //$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
            $result = mysqli_query($koneksi, "SELECT * FROM gejala ORDER BY kd_gejala ASC"); // using mysqli_query instead
            ?>
            <div class="table-responsive table-striped">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>KODE GEJALA</th>
                            <th>NAMA GEJALA</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
                        while ($data = mysqli_fetch_array($result)) {
                        ?>
                            <tr>
                                <td><?= $data['kd_gejala']; ?></td>
                                <td><?= $data['gejala']; ?></td>
                                <td><a href="edit_gejala.php?id=<?= $data['kd_gejala']; ?> " class="btn btn-primary btn-circle btn-sm"><i class="fas fa-edit"></i></a>
                                    <a href=" delete_gejala.php?id=<?= $data['kd_gejala']; ?>" onClick="return confirm('Yakin ingin menghapus')" class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
include('templates/footer.php');
?>