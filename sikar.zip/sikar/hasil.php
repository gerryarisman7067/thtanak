<?php include "conn.php"; ?>
<?php include "header.php"; ?>
<div class="container">



  <main role="main">

    <!-- Example row of columns -->
    <div class="row mt-5">
      <div class="col-lg-12">
        <h2>Hasil Diagnosa</h2>
        <?php
        if (isset($_POST['proses'])) {
          $a = $_POST['cek'];
          $aa = implode('AND', $a);
          //echo $aa;
          $sql = mysqli_query($koneksi, "SELECT pencegahan.*, penyakit.*, solusi.*, rule.* 
                                FROM pencegahan, penyakit, solusi, rule  
                                WHERE rule.maka=penyakit.kode AND
                                pencegahan.kode=penyakit.kode AND
                                solusi.kd_pencegahan=pencegahan.kd_pencegahan AND
                                rule.jika='$aa'");
          if (mysqli_num_rows($sql) == 0) {
            header('location:diagnosa.php?error=Tidak ditemukan penyakit dengan gejala tersebut, silahkan cek <a href="daftar.php">daftar penyakit THT</a>');
          } else {
            $row = mysqli_fetch_array($sql);
          }
        }
        ?>
        <table class="table table-bordered table-hover">
          <tr>
            <td>Gejala</td>
            <td>:</td>
            <td>

              <?php
              if (isset($a[0])) {
                $sql1 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[0]'");
                $row1 = mysqli_fetch_array($sql1);
                echo "<ul><li>$row1[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[1])) {
                $sql2 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[1]'");
                $row2 = mysqli_fetch_array($sql2);
                echo "<li>$row2[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[2])) {
                $sql3 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[2]'");
                $row3 = mysqli_fetch_array($sql3);
                echo "<li>$row3[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[3])) {
                $sql4 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[3]'");
                $row4 = mysqli_fetch_array($sql4);
                echo "<li>$row4[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[4])) {
                $sql5 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[4]'");
                $row5 = mysqli_fetch_array($sql5);
                echo "<li>$row5[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[5])) {
                $sql6 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[5]'");
                $row6 = mysqli_fetch_array($sql6);
                echo "<li>$row6[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[6])) {
                $sql7 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[6]'");
                $row7 = mysqli_fetch_array($sql7);
                echo "<li>$row7[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[7])) {
                $sql8 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[7]'");
                $row8 = mysqli_fetch_array($sql8);
                echo "<li>$row8[gejala]</li></ul>";
              } else {
                echo "";
              }
              ?>
            </td>
            <td><a href="cetak-hasil.php?cek=<?php echo $row['jika']; ?>" class="btn btn-sm btn-primary" target="_blank">Download</a></td>
          </tr>
          <tr>
            <td>Penyakit</td>
            <td>:</td>
            <td colspan="2"><?php echo $row['nama_penyakit']; ?></td>
          </tr>
          <tr>
            <td>Penyebab</td>
            <td>:</td>
            <td colspan="2"><?php echo $row['penyebab']; ?></td>
          </tr>
          <tr>
            <td>Pencegahan</td>
            <td>:</td>
            <td colspan="2"><?php echo $row['deskripsi']; ?></td>
          </tr>
          <tr>
            <td>Nama Obat</td>
            <td>:</td>
            <td colspan="2"><?php echo $row['nama_obat']; ?></td>
          </tr>
          <tr>
            <td>Solusi</td>
            <td>:</td>
            <td colspan="2">
              <ul>
                <?php
                $nomor = $row['kd_pencegahan'];
                $query = mysqli_query($koneksi, "SELECT * FROM solusi WHERE kd_pencegahan='$nomor'");
                $no = 0;
                while ($data = mysqli_fetch_array($query)) {
                ?>

                  <li><?php echo $data['solusi']; ?></li>

                <?php }
                ?>
              </ul>
            </td>

          </tr>
        </table>
        <a class="btn btn-sm btn-danger" href="diagnosa.php">Kembali</a>
      </div>
    </div>
    <br /><br />
  </main>

  <?php include "footer.php"; ?>