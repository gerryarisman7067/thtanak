<?php 
$wikipedia_active ="active";
include "templates/header.php"; 
?> 
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/banner.png" class="d-block w-100" alt="...">
            </div>
        </div>
    </div>
<div class="container">
   
    <h1 class="display-4 mt-5">Halaman wikipedia:</h1>
    <h3 class="mt-5">1. Otitis media</h3>
    <li>Demam</li>
    <li>Telinga sakit (p) </li>
    <li>Telinga mengeluarkan cairan berbau (p)</li>
    <li>Gangguan pendengaran (p)</li></br>
    <p>
        Otitis media akut Otitis media adalah infeksi pada telinga bagian tengah, tepatnya pada rongga di belakang gendang telinga. Infeksi telinga bagian tengah ini, sering kali timbul akibat batuk pilek, flu, atau alergi sebelumnya. kebanyakan kasus otitis media menyerang anak-anak yang berusia di bawah tiga tahun. Penyebab penyakit ini antara lain akibat terpapar asap rokok, kebiasaan meminum susu sambal berbaring dan kebersihan lingkungan
    </p>
    <h3>2. Serumen</h3>
    <li>Telinga sakit (p)</li>
    <li>Riwayat mengorek telinga</li>
    <li>Gangguan pendengaran (p)</li>
    <li>Telinga mampet (p)</li></br>
    <p>Kotoran telinga dihasilkan oleh kelenjar minyak di dalam liang telinga untuk melindungi dan membersihkan telinga dari debu, kuman, serta benda asing. Serumen juga berfungsi untuk menghambat pertumbuhan bakteri di dalam saluran telinga sehingga tidak terjadi infeksi.</p>
    <h3>3. Otitis eksterna</h3>
    <li>Telinga sakit (p) </li>
    <li>Riwayat mengorek telinga</li>
    <li>Gangguan pendengaran (p)</li>
    <li>Telinga mampet </li>
    <li>Telinga berair (p)</li>
    <li>Telinga berdengung</li>
    <p>Otitis eksterna adalah infeksi pada saluran telinga luar. Kondisi ini biasanya terjadi akibat masuknya air ke dalam telinga saat mandi atau berenang dan air tidak bisa keluar, sehingga kondisi liang telinga menjadi lembab dan memicu pertumbuhan bakteri</p>
    <h3>4. Sinusitis</h3>
    <li>Bersin terus menerus (p)</li>
    <li>Mengeluarkan ingus bening atau kehijauan (p)</li>
    <li>Demam </li>
    <li>Nyeri pada bagian wajah (p)</li>
    <p>Sinusitis adalah inflamasi atau peradangan pada dinding sinus. Sinus merupakan rongga kecil yang saling terhubung melalui saluran udara di dalam tulang tengkorak. Sinus terletak di bagian belakang tulang dahi, bagian dalam struktur tulang pipi, kedua sisi batang hidung, dan belakang mata. Penyebab penyait ini antara lain ialah infeksi kuman, alergi atau polip.</p>
    <h3>5. Rhinitis</h3>
    <li>Bersin (p)</li>
    <li>batuk</li>
    <li>Mata bengkak dan berair (p)</li>
    <li>Hidung mampet (p)</li>
    <li>Lemas (p)</li>
    <p>Rhinitis adalah peradangan atau iritasi di lapisan dalam hidung, yang ditandai dengan gejala berupa pilek, hidung tersumbat, dan bersin-bersin. Rhinitis paling sering muncul akibat alergi, misalnya terhadap bulu hewan peliharaan, serbuk sari, asap, dan debu. Selain itu, infeksi, obat-obatan, dan perubahan cuaca juga dapat menyebabkan rhinitis.</p>

    <h3>6. Radang tenggorokkan</h3>
    <li>Demam (p)</li>
    <li>Sakit tenggorokkan (p)</li>
    <li>Nyeri menelan (p)</li>
    <li>Pembengkakan pada leher (p)</li>
    <li>Bercak kemerahan pada langit langit mulut</li>
    <li>Nafas berbau</li>
    <p>Radang tenggorokan adalah suatu peradangan pada tenggorokan yang disebabkan oleh infeksi. Infeksi ini umumnya bersifat akut dan menyerang saluran tenggorokan. Radang atau disebut juga faringitis streptokokus merupakan infeksi menular yang dapat ditularkan melalui kontak langsung dengan penderitanya. Penyebab penyakit ini antar lain ialah infeksi virus atau bakteri dan paparan asap rokok.</p>

    <h3>7. Radang amandel</h3>
    <li>Demam (p)</li>
    <li>Sakit tenggorokkan (p)</li>
    <li>Nyeri menelan (p)</li>
    <li>Pembengkakann pada leher</li>
    <li>Bercak kemerahan pada mulut</li>
    <li>Amandel bengkak dan memerah (p)</li>
    <li>Nafas berbau</li>
    <p>Radang amandel atau tonsilitis adalah kondisi di mana amandel mengalami peradangan atau inflamasi. Amandel atau tonsil merupakan dua kelenjar kecil yang ada di tenggorokan. Organ ini berfungsi untuk mencegah infeksi, khususnya pada anak-anak. Penyebab penyakit ini antara lain ialah infeksi virus dan infeksi bakteri</p>


    <h3>8. Laryngitis</h3>
    <li>Demam (p)</li>
    <li>Sakit tenggorokan (p)</li>
    <li>Tenggorokan kering</li>
    <li>Nyeri saat menelan (p)</li>
    <li>Suara serak atau hilang (p)</li>
    <p>Laryngitis atau penyakit laringitis adalah peradangan yang terjadi pada laring, yaitu bagian dari saluran pernapasan di mana pita suara berada. Kondisi ini dapat disebabkan oleh penggunaan laring yang berlebihan, iritasi, atau infeksi.</p>
</div>
        <?php include "templates/footer.php"; ?>