<?php 
$active_home = "active";
include "templates/header.php" 
?>
  <!-- carosel -->
  <div id="carouselExampleIndicators" class="carousel slide mt-5" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/banner.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/banner1.png" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- and carosel -->
<div class="container">
  <div class="jumbotron">
  <h1 class="display-4">Selamat datang di website kami</h1>
  <p class="lead">Penyakit THT dan Pengobatannya Meski di era kekhalifahan belum ada peralatan yang bisa digunakan untuk mendiagnosis penyakit, para dokter Muslim telah mampu melakukannya. Bermodalkan observasi yang baik dan keahlian klinis, para dokter itu mampu mendiagnosis penyakit telinga, hidung, dan tenggorokan (THT).</p>
  <hr class="my-4">
  <p>Silahkan tekan tombol di bawan untuk memulai diagnosa.</p>
  <a class="btn btn-primary btn-lg" href="diagnosa.php" role="button">Mulai Diagnosa <i class="bi bi-arrow-right-circle"></i></a>
  </div>
    <div class="row mt-5">
        <h1 class="display-4 mt-5 mb-4">Daftar Penyakit THT ANAK</h1>
        <table class="table table-bordered table-hover">
          <tr>
            <th>
              <center>NO</center>
            </th>
            <th>
              <center>KODE </center>
            </th>
            <th>
              <center>NAMA PENYAKIT</center>
            </th>
            <th>
              <center>PENYEBAB</center>
            </th>
            <th>
              <center>DESKRIPSI</center>
            </th>
          </tr>
          <?php
          include "conn.php";
          $query = mysqli_query($koneksi, "SELECT * FROM penyakit ORDER BY kode ASC");
          $no = 0;
          while ($data = mysqli_fetch_array($query)) {
            $no++;
          ?>
            <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data['kode']; ?></td>
              <td><?php echo $data['nama_penyakit']; ?></td>
              <td><?php echo $data['penyebab']; ?></td>
              <td><a href="deskripsi.php?id=<?php echo $data['kode']; ?>" class="btn btn-sm btn-primary">Detail</a></td>
            </tr>
          <?php } ?>
        </table>
</div>
</div>



<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#02adc6" fill-opacity="1" d="M0,224L48,197.3C96,171,192,117,288,122.7C384,128,480,192,576,202.7C672,213,768,171,864,165.3C960,160,1056,192,1152,218.7C1248,245,1344,267,1392,277.3L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
  <?php include "templates/footer.php"; ?>