<?php include "conn.php"; ?>
<?php include "templates/header.php"; ?>

<div class="container">
    <!-- Example row of columns -->
    <div class="row mt-5">
        <h1 class="display-4 mt-5 mb-4 ">Penjelasan Detail</h1>
        <?php
        $id = $_GET['id'];
        $sql = mysqli_query($koneksi, "SELECT pencegahan.*, penyakit.*, solusi.*, rule.* 
                                FROM pencegahan, penyakit, solusi, rule  
                                WHERE penyakit.kode=rule.maka AND
                                penyakit.kode=pencegahan.kode AND
                                solusi.kd_pencegahan=pencegahan.kd_pencegahan AND
                                penyakit.kode='$id'");
        if (mysqli_num_rows($sql) == 0) {
          header("Location: daftar.php");
        } else {
          $row = mysqli_fetch_array($sql);
        }

        ?>
        <table class="table table-bordered table-hover">
          <tr>
            <td>Penyakit</td>
            <td>:</td>
            <td><?php echo $row['nama_penyakit']; ?></td>
            <!-- <td><a href="cetak-deskripsi.php?id=<?php echo $row['kode']; ?>" class="btn btn-sm btn-primary" target="_blank">Download</a></td> -->

          </tr>
          <tr>
            <td>Gejala</td>
            <td>:</td>
            <td colspan="2">

              <?php
              $ab = $row['jika'];
              $a = explode("AND", $ab);
              if (isset($a[0])) {
                $sql1 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[0]'");
                $row1 = mysqli_fetch_array($sql1);
                echo "<ul><li>$row1[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[1])) {
                $sql2 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[1]'");
                $row2 = mysqli_fetch_array($sql2);
                echo "<li>$row2[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[2])) {
                $sql3 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[2]'");
                $row3 = mysqli_fetch_array($sql3);
                echo "<li>$row3[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[3])) {
                $sql4 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[3]'");
                $row4 = mysqli_fetch_array($sql4);
                echo "<li>$row4[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[4])) {
                $sql5 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[4]'");
                $row5 = mysqli_fetch_array($sql5);
                echo "<li>$row5[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[5])) {
                $sql6 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[5]'");
                $row6 = mysqli_fetch_array($sql6);
                echo "<li>$row6[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[6])) {
                $sql7 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[6]'");
                $row7 = mysqli_fetch_array($sql7);
                echo "<li>$row7[gejala]</li>";
              } else {
                echo "";
              }
              ?>
              <?php
              if (isset($a[7])) {
                $sql8 = mysqli_query($koneksi, "SELECT * FROM  gejala WHERE kd_gejala='$a[7]'");
                $row8 = mysqli_fetch_array($sql8);
                echo "<li>$row8[gejala]</li></ul>";
              } else {
                echo "";
              }
              ?>
            </td>
          </tr>
          <tr>
            <td>Saran</td>
            <td>:</td>
            <td colspan="2"><?php echo $row['penyebab']; ?></td>
          </tr>

        </table>
        
      </div>
      <a class="btn btn-sm btn-danger" href="daftar.php"> <i class="bi bi-arrow-left-circle"></i> Kembali</a>
    </div>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#02adc6" fill-opacity="1" d="M0,224L48,197.3C96,171,192,117,288,122.7C384,128,480,192,576,202.7C672,213,768,171,864,165.3C960,160,1056,192,1152,218.7C1248,245,1344,267,1392,277.3L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>

  <?php include "templates/footer.php"; ?>