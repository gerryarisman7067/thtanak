
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" />

    <!-- My Css -->
    <link rel="stylesheet" href="css/style.css" />

    <link rel="icon" type="image/png" href="favicon/favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="favicon/favicon-16x16.png" sizes="16x16" />

    <title>SISTEM PAKAR DIAGNOSA PENYAKIT THT ANAK</title>
    
  </head>
  <body>
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark" style="background-color: #02ADC6;">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <img src="img/icon.png" alt="" width="30" height="30" class="d-inline-block align-text-top">
      THT ANAK
    </a>
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="toggler-icon top-bar"></span>
      <span class="toggler-icon middle-bar"></span>
      <span class="toggler-icon bottom-bar"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link <?= $active_home;?>" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $active_diagnosa;?>" href="diagnosa.php">Diagnosa</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $wikipedia_active;?>" href="wikipedia.php">Wikipedia</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $active_about;?>" href="profil.php">About</a>
        </li>
        <li class="nav-item">
          <a class="btn btn-outline-info" href="admin/login.php">Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>