
<?php 
$active_about ="active";
include "templates/header.php"; 
?>
<div class="container text-center">
    <div class="row mt-5 justify-content-center">
        <h1 class="display-4 mt-5">About</h1>
        <p class="lead">Aplikasi Sistem Pakar Diagnosa Penyakit THT ANAK</p>
        <div class="col-md-6">
          <img src="img/icon.png"/>
        </div>
            


      </div>
</div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#02adc6" fill-opacity="1" d="M0,224L48,197.3C96,171,192,117,288,122.7C384,128,480,192,576,202.7C672,213,768,171,864,165.3C960,160,1056,192,1152,218.7C1248,245,1344,267,1392,277.3L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>


  <?php include "templates/footer.php"; ?>