<?php 
include "conn.php";
$active_diagnosa = "active";
include "templates/header.php"; 
?>
  <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="img/banner.png" class="d-block w-100" alt="...">
      </div>
    </div>
  </div>

    <!-- Example row of columns -->
    <div class="container">
    <div class="row mt-5">
        <h1 class="display-4">Diagnosa</h1>
        <p class="lead">Silahkan pilih gejala penyakit sesuai yang anda alami di bawah ini:</p>
        <?php if (isset($_GET['error'])) {
          echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
$_GET[error]
</div>";
        } else {
          echo "";
        } ?>
        <form method="POST" action="hasil.php" name="diagnosa" enctype="form-data/multipart">
          <ul class="list-group">
            <li class="list-group-item" style="background-color: #02adc6; color:#ffffff" aria-current="true">GEJALA PENYAKIT THT</li>
            <?php
            $query = mysqli_query($koneksi, "SELECT * FROM gejala ORDER BY kd_gejala ASC");
            $no = 0;
            while ($data = mysqli_fetch_array($query)) {
              $a = $data['gejala'];
              $no++;
            ?>

              <li class="list-group-item"><?php echo $no; ?>. <input type="checkbox" value="<?php echo $data['kd_gejala']; ?>" name="cek[]" /> <?php echo $data['gejala']; ?>
                <br />
              <?php } ?>
              </li>
          </ul><br />
          <input type="submit" class="btn btn-lg btn-primary" value="Start Diagnosa" name="proses" />
        </form>
      </div>
    </div>
  </div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#02adc6" fill-opacity="1" d="M0,224L48,197.3C96,171,192,117,288,122.7C384,128,480,192,576,202.7C672,213,768,171,864,165.3C960,160,1056,192,1152,218.7C1248,245,1344,267,1392,277.3L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
  <?php include "templates/footer.php"; ?>